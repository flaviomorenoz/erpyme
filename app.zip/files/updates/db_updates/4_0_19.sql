UPDATE `tec_settings` SET `version` = '4.0.19' WHERE `setting_id` = 1;
